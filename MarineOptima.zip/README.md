
# MarineOptima: Navigating Efficiency and Sustainability in Commercial Shipping

## Description

MarineOptima is a route optimization tool designed for commercial shipping vessels. It aims to enhance fuel efficiency and reduce operational costs by calculating the most optimal navigation paths between ports, taking into account real-time weather data and maritime traffic.

## Features

- **Route Optimization**: Calculates the most efficient route between two ports.
- **Real-Time Weather Integration**: Utilizes real-time weather data to adjust routes for safety and efficiency.
- **Fuel Consumption Estimation**: Estimates fuel consumption based on ship speed, weather conditions, and sea currents.
- **Avoidance of Congested Areas**: Integrates maritime traffic data to avoid busy shipping lanes.
- **Sustainability Focus**: Aims to reduce the environmental footprint by minimizing fuel consumption.

## Technologies Used

- **Python 3.8+**
- **APIs**: OpenWeatherMap API for weather data.
- **Algorithms**: A* pathfinding algorithm for route optimization.
- **GIS Data**: Geospatial data for mapping and calculations.

## Installation

1. **Clone the Repository**

   ```bash
   git clone https://github.com/yourusername/MarineOptima.git
   ```

2. **Navigate to the Project Directory**

   ```bash
   cd MarineOptima
   ```

3. **Create a Virtual Environment (Optional but Recommended)**

   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

4. **Install Dependencies**

   ```bash
   pip install -r requirements.txt
   ```

5. **Set Up API Keys**

   - Rename the file `config_example.json` to `config.json`.
   - Insert your OpenWeatherMap API key into `config.json`.

## Usage

Run the main application:

```bash
python src/main.py
```

Follow the on-screen instructions to input the departure and destination ports.

## Project Structure

- `src/main.py`: Main application script.
- `src/utils.py`: Utility functions and classes.
- `data/ports.csv`: CSV file containing port coordinates.
- `requirements.txt`: Project dependencies.
- `README.md`: Project documentation.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements.

## License

This project is licensed under the MIT License.
    