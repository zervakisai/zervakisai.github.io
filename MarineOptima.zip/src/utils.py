
import heapq
import requests
import math
import csv
import json
import time
from haversine import haversine, Unit

# Φόρτωση ρυθμίσεων
with open('config.json', 'r') as f:
    CONFIG = json.load(f)

API_KEY = CONFIG['openweathermap_api_key']

class Node:
    def __init__(self, coord):
        self.coord = coord
        self.neighbors = []

    def add_neighbor(self, neighbor_node):
        self.neighbors.append(neighbor_node)

def get_weather_data(lat, lon):
    url = (
        f'http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API_KEY}'
    )
    try:
        response = requests.get(url)
        data = response.json()
        wind_speed = data['wind']['speed']
        wave_height = 2
        return {'wind_speed': wind_speed, 'wave_height': wave_height}
    except:
        return {'wind_speed': 5, 'wave_height': 1}

def calculate_cost(coord1, coord2):
    distance = haversine(coord1, coord2, unit=Unit.NAUTICAL_MILES)
    weather = get_weather_data(*coord2)
    wind_speed = weather['wind_speed']
    wave_height = weather['wave_height']
    cost = distance * (1 + wind_speed / 10 + wave_height / 5)
    return cost

def a_star(graph, start_coord, goal_coord):
    start_node = graph[start_coord]
    goal_node = graph[goal_coord]
    open_set = []
    heapq.heappush(open_set, (0, start_node))
    came_from = {}
    g_score = {start_node.coord: 0}
    f_score = {start_node.coord: haversine(start_node.coord, goal_node.coord)}
    while open_set:
        current = heapq.heappop(open_set)[1]
        if current.coord == goal_node.coord:
            return reconstruct_path(came_from, current.coord)
        for neighbor in current.neighbors:
            tentative_g_score = g_score[current.coord] + calculate_cost(
                current.coord, neighbor.coord
            )
            if neighbor.coord not in g_score or tentative_g_score < g_score[neighbor.coord]:
                came_from[neighbor.coord] = current.coord
                g_score[neighbor.coord] = tentative_g_score
                f_score_neighbor = tentative_g_score + haversine(
                    neighbor.coord, goal_node.coord
                )
                f_score[neighbor.coord] = f_score_neighbor
                heapq.heappush(open_set, (f_score_neighbor, neighbor))
        time.sleep(0.1)
    return None

def reconstruct_path(came_from, current_coord):
    total_path = [current_coord]
    while current_coord in came_from:
        current_coord = came_from[current_coord]
        total_path.insert(0, current_coord)
    return total_path

def create_graph(start_coord, goal_coord):
    graph = {}
    start_node = Node(start_coord)
    goal_node = Node(goal_coord)
    graph[start_coord] = start_node
    graph[goal_coord] = goal_node
    start_node.add_neighbor(goal_node)
    goal_node.add_neighbor(start_node)
    return graph

def get_port_coordinates(file_path):
    ports = {}
    with open(file_path, mode='r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            port_name = row['PortName']
            latitude = float(row['Latitude'])
            longitude = float(row['Longitude'])
            ports[port_name] = (latitude, longitude)
    return ports

def calculate_total_cost(path):
    total_cost = 0
    for i in range(1, len(path)):
        cost = calculate_cost(path[i - 1], path[i])
        total_cost += cost
    return total_cost
    