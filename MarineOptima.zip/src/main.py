
import json
import time
from utils import (
    Node,
    haversine,
    a_star,
    create_graph,
    get_port_coordinates,
    calculate_total_cost,
)

def main():
    print("MarineOptima: Navigating Efficiency and Sustainability in Commercial Shipping\n")
    # Φόρτωση λιμανιών
    ports = get_port_coordinates('data/ports.csv')
    # Επιλογή λιμανιού αναχώρησης και προορισμού
    departure = input("Enter departure port: ").strip()
    destination = input("Enter destination port: ").strip()

    if departure not in ports or destination not in ports:
        print("Invalid port names. Please check the port list.")
        return

    start_coord = ports[departure]
    goal_coord = ports[destination]

    # Δημιουργία γραφήματος
    graph = create_graph(start_coord, goal_coord)

    # Εύρεση βέλτιστης διαδρομής
    path = a_star(graph, start_coord, goal_coord)

    if path:
        print("\nOptimal route found:")
        total_cost = calculate_total_cost(path)
        for i, coord in enumerate(path):
            print(f"Waypoint {i + 1}: Latitude {coord[0]}, Longitude {coord[1]}")
        print(f"\nEstimated Total Cost: {total_cost:.2f} units")
    else:
        print("No route found between the selected ports.")

if __name__ == "__main__":
    main()
    