
# Marine Fleet Optimization Project

## Overview
This project is designed to analyze and optimize the fuel consumption and emissions of a marine fleet based on historical data.
It includes analysis scripts, optimization algorithms, and configuration files for thresholds and visualization settings.

## Project Structure
- **data/**: Contains the operational data (`large_vessel_data.csv`).
- **src/**: Holds the main analysis (`analysis.py`) and optimization (`optimization.py`) scripts.
- **config/**: Configuration settings for thresholds in `config.json`.
- **requirements.txt**: Lists necessary Python libraries for the project.

## Setup Instructions
1. Install dependencies with `pip install -r requirements.txt`.
2. Run `src/analysis.py` for exploratory data analysis and visualization.
3. Use `src/optimization.py` to apply optimization strategies based on the configuration.

## Usage
1. Clone the repository.
2. Install dependencies.
3. Use `config/config.json` to adjust parameters like fuel and emission thresholds.
4. Run the analysis and optimization scripts as needed.

## License
This project is licensed under the MIT License.
