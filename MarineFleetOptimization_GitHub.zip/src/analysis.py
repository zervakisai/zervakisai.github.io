
import pandas as pd
import matplotlib.pyplot as plt

def load_data(filepath):
    """Load dataset from the specified CSV file."""
    return pd.read_csv(filepath)

def perform_eda(data):
    """Perform exploratory data analysis and generate visualizations."""
    print("Data Description:")
    print(data.describe())
    
    # Visualizing trends
    plt.figure(figsize=(10, 6))
    plt.plot(data['date'], data['fuel_consumption'], label='Fuel Consumption', color='blue')
    plt.plot(data['date'], data['emissions'], label='Emissions', color='red')
    plt.xlabel("Date")
    plt.ylabel("Values")
    plt.legend()
    plt.title("Fuel Consumption and Emissions Over Time")
    plt.show()

def main():
    data = load_data('../data/large_vessel_data.csv')
    perform_eda(data)

if __name__ == "__main__":
    main()
