
import pandas as pd

def optimize_fuel_consumption(data, fuel_threshold, emission_threshold):
    """Optimize the fuel consumption based on given thresholds."""
    optimized_data = data.copy()
    optimized_data['optimized_fuel'] = optimized_data['fuel_consumption'].apply(
        lambda x: x * 0.9 if x > fuel_threshold else x
    )
    optimized_data['optimized_emissions'] = optimized_data['emissions'].apply(
        lambda x: x * 0.95 if x > emission_threshold else x
    )
    return optimized_data

def main():
    data = pd.read_csv('../data/large_vessel_data.csv')
    optimized_data = optimize_fuel_consumption(data, fuel_threshold=550, emission_threshold=55)
    print("Optimized Data Preview:")
    print(optimized_data.head())

if __name__ == "__main__":
    main()
