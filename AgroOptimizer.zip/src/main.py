
import json
import time
import pandas as pd
from utils import (
    get_weather_data,
    recommend_irrigation,
    recommend_fertilizer,
    predict_yield
)

def main():
    print("AgroOptimizer: Smart Optimization for Crop Yield and Resource Management\n")
    
    fields = pd.read_csv('data/fields.csv')
    print("Fields Loaded:\n", fields)
    
    field_name = input("Enter field name: ").strip()
    crop_type = input("Enter crop type: ").strip()
    
    if field_name not in fields['FieldName'].values:
        print("Field not found. Please check the field list.")
        return

    weather_data = get_weather_data(field_name)
    print("\nWeather Data:", weather_data)

    irrigation = recommend_irrigation(weather_data, crop_type)
    fertilizer = recommend_fertilizer(crop_type)

    yield_prediction = predict_yield(fields, crop_type, irrigation, fertilizer)
    
    print("\nOptimization Recommendations:")
    print(f"Irrigation Requirement: {irrigation} liters per hectare")
    print(f"Fertilizer Requirement: {fertilizer} kg per hectare")
    print(f"Predicted Yield: {yield_prediction} tons per hectare")

if __name__ == "__main__":
    main()
    