
import requests
import json

with open('config.json', 'r') as f:
    CONFIG = json.load(f)

API_KEY = CONFIG['openweathermap_api_key']

def get_weather_data(field_name):
    coordinates = {"latitude": 37.5, "longitude": 23.5}
    url = f"http://api.openweathermap.org/data/2.5/weather?lat={coordinates['latitude']}&lon={coordinates['longitude']}&appid={API_KEY}"
    response = requests.get(url)
    data = response.json()
    return {
        "temperature": data["main"]["temp"],
        "humidity": data["main"]["humidity"],
        "rain": data["rain"]["1h"] if "rain" in data else 0
    }

def recommend_irrigation(weather_data, crop_type):
    base_irrigation = 100
    if weather_data['rain'] > 5:
        irrigation = base_irrigation * 0.8
    else:
        irrigation = base_irrigation
    return irrigation

def recommend_fertilizer(crop_type):
    fertilizer_requirements = {
        "wheat": 50,
        "corn": 70,
        "soy": 45
    }
    return fertilizer_requirements.get(crop_type.lower(), 50)

def predict_yield(fields, crop_type, irrigation, fertilizer):
    base_yield = 3.0
    yield_increase = (irrigation / 100) + (fertilizer / 50)
    return base_yield * (1 + yield_increase)
