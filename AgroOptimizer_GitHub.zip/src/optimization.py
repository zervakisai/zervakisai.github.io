
import pandas as pd

def optimize_resources(data, yield_goal, water_limit, fertilizer_limit):
    """Optimize resource usage for crops to meet yield goals within limits."""
    optimized_data = data.copy()
    optimized_data['optimized_yield'] = optimized_data['yield'].apply(
        lambda y: y * 1.1 if y < yield_goal else y
    )
    optimized_data['optimized_water'] = optimized_data['water_usage'].apply(
        lambda w: w * 0.9 if w > water_limit else w
    )
    optimized_data['optimized_fertilizer'] = optimized_data['fertilizer_usage'].apply(
        lambda f: f * 0.95 if f > fertilizer_limit else f
    )
    return optimized_data

def main():
    data = pd.read_csv('../data/crop_data.csv')
    optimized_data = optimize_resources(data, yield_goal=600, water_limit=110, fertilizer_limit=12)
    print("Optimized Data Preview:")
    print(optimized_data.head())

if __name__ == "__main__":
    main()
