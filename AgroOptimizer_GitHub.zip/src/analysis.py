
import pandas as pd
import matplotlib.pyplot as plt

def load_data(filepath):
    """Load crop data from a CSV file."""
    return pd.read_csv(filepath)

def perform_eda(data):
    """Perform EDA on crop data and visualize metrics."""
    print("Data Summary:")
    print(data.describe())
    
    plt.figure(figsize=(10, 6))
    plt.plot(data['date'], data['yield'], label='Crop Yield', color='green')
    plt.plot(data['date'], data['water_usage'], label='Water Usage', color='blue')
    plt.xlabel("Date")
    plt.ylabel("Values")
    plt.legend()
    plt.title("Crop Yield and Water Usage Over Time")
    plt.show()

def main():
    data = load_data('../data/crop_data.csv')
    perform_eda(data)

if __name__ == "__main__":
    main()
